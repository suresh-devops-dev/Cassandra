package com.vz.cassandraTool.util;
@FunctionalInterface
public interface LinuxClient {
	void LinuxConnectivity();

}
