package com.vz.cassandraTool.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vz.cassandraTool.pojo.JobRun;

@Service
public class JobRunService {

	public List<JobRun> runInitJob() {
		return null;
	}

	public List<JobRun> processInitFile() {
		return null;
	}

}
