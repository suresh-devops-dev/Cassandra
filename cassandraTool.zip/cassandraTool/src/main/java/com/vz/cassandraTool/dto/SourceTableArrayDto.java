package com.vz.cassandraTool.dto;

public class SourceTableArrayDto {
	private int[] sourceTableId;

	public int[] getSourceTableId() {
		return sourceTableId;
	}

	public void setSourceTableId(int[] sourceTableId) {
		this.sourceTableId = sourceTableId;
	}

}
