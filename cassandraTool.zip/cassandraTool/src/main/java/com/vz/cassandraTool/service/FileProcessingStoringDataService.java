package com.vz.cassandraTool.service;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.vz.cassandraTool.dto.JobRunDTO1;
import com.vz.cassandraTool.pojo.CassandraTable;
import com.vz.cassandraTool.pojo.ErrorLog;
import com.vz.cassandraTool.pojo.FileProcess;
import com.vz.cassandraTool.pojo.JobRun;
import com.vz.cassandraTool.pojo.SourceTable;
import com.vz.cassandraTool.pojo.System;
import com.vz.cassandraTool.repo.CassandraTableRepo;
import com.vz.cassandraTool.repo.ErrorLogRepo;
import com.vz.cassandraTool.repo.FileProcessRepo;
import com.vz.cassandraTool.repo.JobRunRepo;
import com.vz.cassandraTool.repo.SourceTableRepo;
@Service
public class FileProcessingStoringDataService {
	@Autowired
	ErrorLogRepo errorLogRepo;
	@Autowired
	FileProcessRepo fileProcessRepo;
	@Autowired
	JobRunRepo jobRunRepo;
	@Autowired
	CassandraTableRepo cassandraTableRepo;
	@Autowired
	SourceTableRepo sourceTableRepo;
	@Autowired
	FileProcessingService fileProcessingService;
	
	public ResponseEntity<String> processInitFileData(@RequestBody JobRunDTO1 migrationData) throws JSONException {
	FileProcess fileprocess = new FileProcess();
	ErrorLog errLog = new ErrorLog();

	// set job run data
	JobRun jr = new JobRun();
	jr.setFrequency(migrationData.getFrequency());
	jr.setEnvironmentName(migrationData.getEnvironmentName());
	jr.setInstance(migrationData.getInstance());
	jr.setIsRecon(migrationData.getIsRecon());

	String cassTableString = IntStream.of(migrationData.getCassandraTable()).mapToObj(Integer::toString)
			.collect(Collectors.joining(", "));
	jr.setCassandraTableString(cassTableString);

	String srcTableString = IntStream.of(migrationData.getSourceTable()).mapToObj(Integer::toString)
			.collect(Collectors.joining(", "));
	jr.setSourceTableString(srcTableString);

	Integer a = migrationData.getCassandraTable()[0];
	CassandraTable cassanTabl = new CassandraTable();
	cassanTabl.setCassandraTableId(a);
	jr.setCassandraTable(cassanTabl);

	Integer b = migrationData.getSourceTable()[0];
	SourceTable srcTable = new SourceTable();
	srcTable.setSourceTableId(b);
	jr.setSourceTable(srcTable);

	System sys = new System();
	sys.setSystemId(migrationData.getSystemId());
	jr.setSystem(sys);

	jr.setFeedFileName(migrationData.getFeedFileName());
	jr.setFrequency(migrationData.getFrequency());
	jr.setStatus("In Progress");
	jobRunRepo.save(jr);
	// end of job run data

	int jobRunIdTemp = jr.getJobRunId();
	JobRun jobRun = jobRunRepo.findByJobRunId(jobRunIdTemp);
	fileprocess.setJobRun(jobRun);

	// ui side return responnce saying in progress and continue shell process->
	fileprocess.setStatus("In Progress");
	fileProcessRepo.save(fileprocess);
	// end file process
	// Process the file
	String processFile = fileProcessingService.processFile(migrationData);
	JSONObject jsonObj = new JSONObject();
	jsonObj.put("processFileExitStatus", "Completed");
	jsonObj.put("linuxStatus", processFile);
	if (processFile.trim().contentEquals("0")) {
		jsonObj.put("message", "Success");
		jsonObj.put("statusCode", 200);
		// change later to remove
		errLog.setErrorCode("0");
		errLog.setErrorName("no error");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Completed");
		jobRunRepo.save(jr);
	} else if (processFile.trim().contentEquals("255")) {
		jsonObj.put("message", "Connection timed out");
		jsonObj.put("statusCode", 200);
		errLog.setErrorCode("255");
		errLog.setErrorName("connection timed out");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Failed");
		jobRunRepo.save(jr);
		fileprocess.setErrorLog(errLog);

	} else if (processFile.trim().contentEquals("127")) {
		jsonObj.put("message", "Failed");
		jsonObj.put("statusCode", 200);
		errLog.setErrorCode(processFile.trim());
		errLog.setErrorName("command not found");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Failed");
		jobRunRepo.save(jr);
		fileprocess.setErrorLog(errLog);
	} else if (processFile.trim().contentEquals("2")) {
		jsonObj.put("message", "Latest file is not found");
		jsonObj.put("statusCode", 200);
		errLog.setErrorCode(processFile.trim());
		errLog.setErrorName("Latest file is not found");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Failed");
		jobRunRepo.save(jr);
		fileprocess.setErrorLog(errLog);
	}else if (processFile.trim().contentEquals("3")) {
		jsonObj.put("message", "Control File is not found");
		jsonObj.put("statusCode", 200);
		errLog.setErrorCode(processFile.trim());
		errLog.setErrorName("Control File is not found");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Failed");
		jobRunRepo.save(jr);
		fileprocess.setErrorLog(errLog);
	} 
	else {
		jsonObj.put("message", "Failed");
		jsonObj.put("statusCode", 200);
		errLog.setErrorCode(processFile.trim());
		errLog.setErrorName("Failed");
		errorLogRepo.save(errLog);
		jr.setErrorLog(errLog);
		jr.setStatus("Failed");
		jobRunRepo.save(jr);
		fileprocess.setErrorLog(errLog);
	}
	if (processFile.equals("0")) {
		fileprocess.setStatus("Success");
	} else {
		fileprocess.setStatus("Failed");
	}
	fileProcessRepo.save(fileprocess);

	return ResponseEntity.ok(jsonObj.toString());
}
}
