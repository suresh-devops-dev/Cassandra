package com.vz.cassandraTool.dto;

public class FileProcessDto {

	private int isRecon;

	public int getIsRecon() {
		return isRecon;
	}

	public void setIsRecon(int isRecon) {
		this.isRecon = isRecon;
	}

}
