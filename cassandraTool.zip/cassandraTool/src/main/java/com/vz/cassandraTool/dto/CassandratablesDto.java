package com.vz.cassandraTool.dto;

public class CassandratablesDto {

	private int cassandraTableId;
	private String cassandraTableName;

	public int getCassandraTableId() {
		return cassandraTableId;
	}

	public void setCassandraTableId(int cassandraTableId) {
		this.cassandraTableId = cassandraTableId;
	}

	public String getCassandraTableName() {
		return cassandraTableName;
	}

	public void setCassandraTableName(String cassandraTableName) {
		this.cassandraTableName = cassandraTableName;
	}

}
