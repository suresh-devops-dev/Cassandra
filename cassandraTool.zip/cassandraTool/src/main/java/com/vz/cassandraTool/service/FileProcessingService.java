package com.vz.cassandraTool.service;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.python.google.common.base.Joiner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.vz.cassandraTool.dto.JobRunDTO1;
import com.vz.cassandraTool.repo.CassandraTableRepo;
import com.vz.cassandraTool.repo.SourceTableRepo;

@Service
public class FileProcessingService {
	@Autowired
	SourceTableRepo sourceTable;

	@Autowired
	CassandraTableRepo cassandraTableRepo;

	@Value("${T1.hostname}")
	String t1HostName;

	@Value("${T1.userName}")
	String t1UserName;

	@Value("${T1.password}")
	String t1Password;

	@Value("${T2.hostname}")
	String t2HostName;

	@Value("${T2.userName}")
	String t2UserName;

	@Value("${T2.password}")
	String t2Password;

	@Value("${T3.hostName}")
	String t3HostName;

	@Value("${T3.userName}")
	String t3UserName;

	@Value("${T3.password}")
	String t3Password;

	@Value("${T4.hostName}")
	String t4HostName;

	@Value("${T4.userName}")
	String t4UserName;

	@Value("${T4.password}")
	String t4Password;

	@Value("${loaderServer1}")
	String loaderServer1;

	@Value("${loaderServer2}")
	String loaderServer2;

	public String processFile(JobRunDTO1 jobRun) {

		String instance = jobRun.getInstance().toUpperCase();
		String environment = jobRun.getEnvironmentName().toUpperCase();
		String hostName = "";
		String userName = "";
		String password = "";
		String response = null;
		String loaderServer = null;
		// to find the recon filename
		String command = null;
		// find list of control file from cassandra tables
		int[] cassTable = jobRun.getCassandraTable();
		List<String> tableID = new ArrayList<>();
		for (int id : cassTable) {
			String idToStr = String.valueOf(id);
			tableID.add(idToStr);
		}
		List<String> list = cassandraTableRepo.findConfFileName(tableID);
		List<String> cntlfile = cassandraTableRepo.findCtlFileName(tableID);

		List<String> contrlFileList = new ArrayList<>();

		String contrlFileName[] = new String[cntlfile.size()];
		for (int i = 0; i < cntlfile.size(); i++) {
			if(!cntlfile.get(i).trim().isEmpty()) {
			contrlFileName[i] = cntlfile.get(i).trim();
			contrlFileList.add(contrlFileName[i]);
			}
		}
		String contrlFileName1 = contrlFileList.get(0);
		String trimmedcontrlfile = contrlFileName1.substring(0, contrlFileName1.indexOf("_"));
		Date date1 = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yy/MM/dd");
		String strDate = formatter.format(date1);
		String replace = strDate.replace("/", "");
		String grepFile = trimmedcontrlfile.concat(replace);
		
		List<String> confList = new ArrayList();
		String confFileNameList[] = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			confFileNameList[i] = list.get(i).trim();
			confList.add(confFileNameList[i]);
		}
		String delim = ",";
		String res = Joiner.on(delim).join(confList);
		String confres = "'" + res + "'";
		System.out.println(res);
		Calendar cal = Calendar.getInstance();
		Date today = Calendar.getInstance().getTime();
		int date = cal.get(Calendar.DAY_OF_MONTH);
		String day = today.toString().substring(0, 3);
		switch (environment) {
		case "T1":
			hostName = t1HostName;
			userName = t1UserName;
			password = t1Password;
			loaderServer = loaderServer1;
			break;
		case "T2":
			hostName = t2HostName;
			userName = t2UserName;
			password = t2Password;
			loaderServer = loaderServer1;
			break;
		case "T3":
			hostName = t3HostName;
			userName = t3UserName;
			password = t3Password;
			loaderServer = loaderServer1;
			break;
		case "T4":
			hostName = t4HostName;
			userName = t4UserName;
			password = t4Password;
			loaderServer = loaderServer1;
			break;
		default:
			break;
		}

		if (jobRun.getIsRecon() == 1) {

			if (jobRun.getFrequency().equalsIgnoreCase("WEEKLY")) {
				command = "sh recon.sh " + instance + " " + jobRun.getFrequency().toUpperCase() + " " + confres + " "
						+ jobRun.getSystemId();
			} else if (jobRun.getFrequency().equalsIgnoreCase("DAILY")) {
				command = "sh recon.sh " + instance + " " + jobRun.getFrequency().toUpperCase() + " " + confres + " "
						+ day + " " + jobRun.getSystemId();
			} else {
				command = "sh recon.sh " + instance + " " + jobRun.getFrequency().toUpperCase() + " " + confres + " "
						+ date + " " + jobRun.getSystemId();
			}
		} else {
			command = "sh init_fun_backup.sh " + "hari@" + loaderServer + " " + instance + " " + environment + " "
					+ grepFile;
		}
		response = runScript(userName, password, hostName, command);
		return response;
	}

	private String runScript(String userName, String password, String hostName, String command) {

		String response = null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			Session session = jsch.getSession(userName, hostName.trim(), 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);
			InputStream in = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					System.out.print(new String(tmp, 0, i));
				}
				if (channel.isClosed()) {
					System.out.println("exit-status: " + channel.getExitStatus());
					response = String.valueOf(channel.getExitStatus());
					return response;
				}
				sleep();
			}
		} catch (com.jcraft.jsch.JSchException e) {
			System.err.println("Connection timed out: connect");
			response = "255";
			return response;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	private void sleep() {
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
