package com.vz.cassandraTool.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vz.cassandraTool.pojo.CassandraTable;
import com.vz.cassandraTool.pojo.FileProcess;

public interface FileProcessRepo  extends JpaRepository<FileProcess, Integer>  {

	@Query(value = "SELECT * FROM file_process f inner join job_run j on f.jobRunId = j.jobRunId where j.isRecon=1 ORDER BY f.fileProcessId DESC", nativeQuery = true)
	List<FileProcess> findProcessIsReconList();

	@Query(value = "SELECT * FROM file_process f inner join job_run j on f.jobRunId = j.jobRunId where j.isRecon=0  ORDER BY f.fileProcessId DESC", nativeQuery = true)
	List<FileProcess> findProcessInitList();

}
