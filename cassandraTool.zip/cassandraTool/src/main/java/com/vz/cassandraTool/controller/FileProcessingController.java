package com.vz.cassandraTool.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vz.cassandraTool.dto.FileProcessDto;
import com.vz.cassandraTool.dto.JobRunDTO1;
import com.vz.cassandraTool.pojo.CassandraTable;
import com.vz.cassandraTool.pojo.ErrorLog;
import com.vz.cassandraTool.pojo.FileProcess;
import com.vz.cassandraTool.pojo.JobRun;
import com.vz.cassandraTool.pojo.SourceTable;
import com.vz.cassandraTool.pojo.System;
import com.vz.cassandraTool.repo.CassandraTableRepo;
import com.vz.cassandraTool.repo.ErrorLogRepo;
import com.vz.cassandraTool.repo.FileProcessRepo;
import com.vz.cassandraTool.repo.JobRunRepo;
import com.vz.cassandraTool.repo.SourceTableRepo;
import com.vz.cassandraTool.service.FileProcessingService;
import com.vz.cassandraTool.service.FileProcessingStoringDataService;

@CrossOrigin
@RestController
public class FileProcessingController {
	@Autowired
	ErrorLogRepo errorLogRepo;
	@Autowired
	FileProcessRepo fileProcessRepo;
	@Autowired
	JobRunRepo jobRunRepo;
	@Autowired
	CassandraTableRepo cassandraTableRepo;
	@Autowired
	SourceTableRepo sourceTableRepo;
	@Autowired
	FileProcessingService fileProcessingService;
	@Autowired
	FileProcessingStoringDataService fileProcessingStoringDataService;

	@PostMapping("/processFile")
	public ResponseEntity<String> processInitFile(@RequestBody JobRunDTO1 migrationData) throws JSONException {
		
		ResponseEntity<String> processInitFileData = fileProcessingStoringDataService.processInitFileData(migrationData);
		return processInitFileData;
	}
	
	@PostMapping("/getProcessingRequests")
	public ResponseEntity<String> getAllProcessRequests(@RequestBody FileProcessDto fileProcessDto)
			throws JSONException {

		JSONObject jsonObj = new JSONObject();
		JSONArray jsonArray;

		if (fileProcessDto.getIsRecon() == 1) {
			// find isrecon job and process over it
			List<FileProcess> fileProcessIsReconList = fileProcessRepo.findProcessIsReconList();
			jsonArray = getProcessingResult(fileProcessIsReconList, true);
		} else {
			// find init job and process over it
			List<FileProcess> fileProcessInitList = fileProcessRepo.findProcessInitList();
			jsonArray = getProcessingResult(fileProcessInitList, false);
		}
		jsonObj.put("message", "Success");
		jsonObj.put("statusCode", 200);
		jsonObj.put("fileProcessingRequests", jsonArray);
		return ResponseEntity.ok(jsonObj.toString());

	}

	private JSONArray getProcessingResult(List<FileProcess> fileProcessIsReconList, boolean flag) throws JSONException {

		JSONArray jsonArray = new JSONArray();
		for (FileProcess fileProcess : fileProcessIsReconList) {
			int fileProcessId = fileProcess.getFileProcessId();
			JSONObject jsonObjInn = new JSONObject();
			jsonObjInn.put("id", fileProcessId);

			JobRun jobRun = fileProcess.getJobRun();
			//jobRun = fileProcess.getJobRun();

			if (jobRun != null) {

				if (jobRun.getSystem() != null)
					jsonObjInn.put("systemName", jobRun.getSystem().getSystemName());

				// find table name CassandraTableString
				String CassandraTableString = jobRun.getCassandraTableString();
				String[] elements = CassandraTableString.split(",");
				List<String> fixedLenghtList = Arrays.asList(elements);
				// iterate over list to find name
				List<String> cassTableArr = new ArrayList<>();
				for (String string : fixedLenghtList) {
					Integer tableId = Integer.parseInt(string.trim());
					String tableName = cassandraTableRepo.findCassandraTableName(tableId);
					cassTableArr.add(tableName);
				}
				jsonObjInn.put("cassandraTable", cassTableArr);

				// find table name srcTableString
				String srcTableString = jobRun.getSourceTableString();
				String[] elementsSrc = srcTableString.split(",");
				List<String> fixedLenghtListSrc = Arrays.asList(elementsSrc);
				// iterate over list to find name
				List<String> srcTableArr = new ArrayList<>();
				for (String string : fixedLenghtListSrc) {
					Integer tableId = Integer.parseInt(string.trim());
					String tableName = sourceTableRepo.findSourceTableName(tableId);
					srcTableArr.add(tableName);
				}

				jsonObjInn.put("souceTable", srcTableArr);
				jsonObjInn.put("environment", jobRun.getEnvironmentName());
				if (jobRun.getInstance() != null)
					jsonObjInn.put("instance", jobRun.getInstance());

				if (jobRun.getErrorLog() != null) {
					if (!(jobRun.getErrorLog().getErrorCode().equalsIgnoreCase("0")))
						jsonObjInn.put("ErrorMessage", jobRun.getErrorLog().getErrorName());
				}
				if (flag == true) {
					jsonObjInn.put("frequency", jobRun.getFrequency());
				}
			}
			jsonObjInn.put("status", fileProcess.getStatus());
			jsonArray.put(jsonObjInn);
		}
		return jsonArray;
	}
}
