package com.vz.cassandraTool.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vz.cassandraTool.pojo.System;



public interface SystemRepo extends JpaRepository<System, Integer> {

}
