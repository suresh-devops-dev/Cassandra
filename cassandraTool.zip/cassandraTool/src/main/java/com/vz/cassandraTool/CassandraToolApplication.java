package com.vz.cassandraTool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CassandraToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(CassandraToolApplication.class, args);
	}

}
